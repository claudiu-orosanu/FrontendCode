/**
 * Created by user on 6/24/2016.
 */
hrApp.controller('MainController', function($scope, $rootScope) {
    $scope.somevalue = "Claudiu";
    console.log($scope.somevalue);
});