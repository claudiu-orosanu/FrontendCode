/**
 * Created by user on 6/24/2016.
 */
hrApp.controller('MenuController', function ($scope,$rootScope) {
    $scope.demoActionList = [
        {
            label:"OtherScope",
            url: "views/childscope.html"
        }
    ];

});