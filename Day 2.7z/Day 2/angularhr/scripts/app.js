/**
 * Created by user on 6/24/2016.
 */
var hrApp = angular.module('hrApp',[]);